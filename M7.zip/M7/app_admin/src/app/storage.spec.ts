import { Storage } from './storage';

describe('Storage', () => {
  it('should create an instance', () => {
    expect(new Storage()).toBeTruthy();
  });
});
